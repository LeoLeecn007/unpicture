const $ = s => document.querySelector(s);

// 书签代码（效果完全一致）
const bookmarkJS = `(function(){var d=document.documentElement;var m=d.getAttribute('data-dm');if(m==='1'){d.style.filter='';d.style.colorScheme='';d.removeAttribute('data-dm');var imgs=document.querySelectorAll('img,video,canvas,iframe');for(var i=0;i<imgs.length;i++)imgs[i].style.filter='';}else{d.style.filter='invert(0.9) hue-rotate(180deg)';d.style.colorScheme='dark';d.setAttribute('data-dm','1');var imgs=document.querySelectorAll('img,video,canvas,iframe');for(var i=0;i<imgs.length;i++)imgs[i].style.filter='invert(0.9) hue-rotate(180deg)';}})();`;
const bookmarkHref = 'javascript:' + encodeURIComponent(bookmarkJS);

$('#bookmarkletLink').href = bookmarkHref;
$('#bookmarkletCode').textContent = bookmarkJS;

let toastTimer;
function showToast(msg) {
    const toast = $('#toast');
    if (toastTimer) clearTimeout(toastTimer);
    toast.textContent = msg;
    toast.classList.add('show');
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2000);
}

function updatePopupUI(dark) {
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    $('#modeToggle').checked = dark;
    const badge = $('#modeBadge');
    const icon = $('#modeBadgeIcon');
    const text = $('#modeBadgeText');
    if (dark) {
        badge.className = 'mode-badge dark-mode-active';
        icon.textContent = '🌙';
        text.textContent = '深色模式 (全局)';
        $('#headerEmoji').textContent = '🌙';
    } else {
        badge.className = 'mode-badge light-mode-active';
        icon.textContent = '☀️';
        text.textContent = '浅色模式 (全局)';
        $('#headerEmoji').textContent = '🌤️';
    }
}

async function getCurrentTabId() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab?.id || null;
}

async function sendToCurrentPage(action) {
    const tabId = await getCurrentTabId();
    if (tabId) {
        chrome.tabs.sendMessage(tabId, { action }).catch(() => showToast('⚠️ 页面未就绪'));
    } else {
        showToast('⚠️ 无法获取当前页面');
    }
}

async function setGlobalDarkMode(enable) {
    await chrome.storage.local.set({ globalDarkMode: enable });
    updatePopupUI(enable);
    showToast(enable ? '🌙 已开启全局深色' : '☀️ 已关闭全局深色');
}

async function loadState() {
    const { globalDarkMode } = await chrome.storage.local.get('globalDarkMode');
    updatePopupUI(globalDarkMode || false);
}

// 事件绑定
$('#modeToggle').addEventListener('change', () => setGlobalDarkMode($('#modeToggle').checked));
$('#btnSwitchNow').addEventListener('click', () => sendToCurrentPage('toggleDark'));
$('#btnForceLight').addEventListener('click', () => sendToCurrentPage('forceLight'));
$('#btnForceDark').addEventListener('click', () => sendToCurrentPage('forceDark'));

$('#copyBookmarkletBtn').addEventListener('click', () => {
    navigator.clipboard.writeText(bookmarkJS).then(() => showToast('📋 代码已复制'));
});

$('#bookmarkletLink').addEventListener('dragstart', e => {
    e.dataTransfer.setData('text/uri-list', bookmarkHref);
    e.dataTransfer.setData('text/plain', bookmarkHref);
});

// 时钟
function updateClock() {
    const now = new Date();
    $('#clockTime').textContent = now.toLocaleTimeString('zh-CN', { hour12: false });
    $('#clockDate').textContent = now.toLocaleDateString('zh-CN', { year:'numeric', month:'long', day:'numeric', weekday:'short' });
}
setInterval(updateClock, 1000);
updateClock();

loadState();