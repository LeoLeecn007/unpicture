// content.js - 以书签代码的方式操作 DOM，并响应全局开关
const DARK_FILTER = 'invert(0.9) hue-rotate(180deg)';

function applyDarkMode() {
    const html = document.documentElement;
    if (html.getAttribute('data-dm') === '1') return;
    html.style.filter = DARK_FILTER;
    html.style.colorScheme = 'dark';
    html.setAttribute('data-dm', '1');
    const media = document.querySelectorAll('img, video, canvas, iframe');
    for (let el of media) {
        el.style.filter = DARK_FILTER;
    }
}

function removeDarkMode() {
    const html = document.documentElement;
    html.style.filter = '';
    html.style.colorScheme = '';
    html.removeAttribute('data-dm');
    const media = document.querySelectorAll('img, video, canvas, iframe');
    for (let el of media) {
        el.style.filter = '';
    }
}

function syncWithGlobal(globalDark) {
    if (globalDark) {
        applyDarkMode();
    } else {
        removeDarkMode();
    }
}

function toggleLocal() {
    const html = document.documentElement;
    if (html.getAttribute('data-dm') === '1') {
        removeDarkMode();
    } else {
        applyDarkMode();
    }
}

chrome.storage.local.get('globalDarkMode', (result) => {
    syncWithGlobal(result.globalDarkMode || false);
});

chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local' && changes.globalDarkMode) {
        syncWithGlobal(changes.globalDarkMode.newValue);
    }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'toggleDark') {
        toggleLocal();
    } else if (msg.action === 'forceLight') {
        removeDarkMode();
    } else if (msg.action === 'forceDark') {
        applyDarkMode();
    }
});